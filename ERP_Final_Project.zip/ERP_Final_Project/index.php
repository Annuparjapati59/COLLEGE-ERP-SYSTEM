<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <!-- Background Image -->
    <img src="shanti1.jpg" alt="image of college">

  <!-- Clickable Hero Text -->
    <!-- Centered Hero Button -->
    <button class="hero-btn" onclick="location.href='login.html'">
        <h1>Let's IN → </h1>
      
    </button>

    
</body>
</html>