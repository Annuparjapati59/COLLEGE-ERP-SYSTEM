<?php
$conn = new mysqli("localhost","root","","college_erp");

if($conn->connect_error){
    die("Connection failed");
}

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$role = $_POST['role'];

$sql = "INSERT INTO users(name,email,password,role) 
        VALUES('$name','$email','$password','$role')";

if($conn->query($sql)){
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registration Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .box {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            text-align: center;
        }

        .success {
            color: green;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 25px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="box">
    <div class="success">✅ Registered Successfully</div>
    <a href="login.html" class="btn">Go to Login</a>
</div>

</body>
</html>

<?php
}else{
    echo "Error: " . $conn->error;
}
?>