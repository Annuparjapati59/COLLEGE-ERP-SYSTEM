<?php
$conn = new mysqli("localhost","root","","college_erp");

if($conn->connect_error){
    die("Connection failed");
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$username' AND password='$password'";
$result = $conn->query($sql);

if($result->num_rows > 0){
    echo "Login Successful";
} else {
    echo "Invalid Username or Password";
}
?>