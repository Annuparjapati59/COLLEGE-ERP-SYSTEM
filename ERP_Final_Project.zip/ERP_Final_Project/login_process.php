<?php
$conn = new mysqli("localhost","root","","college_erp");

if($conn->connect_error){
    die("Connection failed");
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$username' AND password='$password'";
$result = $conn->query($sql);

if($result->num_rows > 0){
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .box {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            text-align: center;
        }

        .success {
            color: green;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 25px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="box">
    <div class="success">✅ Login Successful</div>
    <a href="home.html" class="btn">Go to Home</a>
</div>

</body>
</html>

<?php
}else{
    echo "Invalid Login";
}
?>