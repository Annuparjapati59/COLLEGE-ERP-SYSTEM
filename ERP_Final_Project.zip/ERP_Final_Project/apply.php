<?php
$conn = new mysqli("localhost", "root", "", "college_erp");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$position = $_POST['position'];
$message = $_POST['message'];

$sql = "INSERT INTO applications (fullname, email, phone, position, message)
VALUES ('$fullname', '$email', '$phone', '$position', '$message')";

if ($conn->query($sql) === TRUE) {
?>
<!DOCTYPE html>
<html>
<head>
  <title>Success</title>
  <style>
    body {
      font-family: Arial;
      background: #f4f4f4;
      text-align: center;
      padding-top: 100px;
    }
    .box {
      background: white;
      display: inline-block;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
    }
    h2 {
      color: green;
    }
    a {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      background: #007bff;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }
    a:hover {
      background: #0056b3;
    }
  </style>
</head>
<body>

<div class="box">
  <h2>✅ Application Submitted Successfully</h2>
  <a href="apply.html">Back</a>
</div>

</body>
</html>

<?php
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>