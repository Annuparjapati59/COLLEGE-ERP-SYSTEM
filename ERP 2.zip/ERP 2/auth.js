const user = JSON.parse(localStorage.getItem("loggedUser"));

if(!user){
    alert("Login required");
    window.location.href = "login.html";
}

if(user.role !== "librarian"){
    alert("Access Denied");
    window.location.href = user.role + "dashboard.html";
}